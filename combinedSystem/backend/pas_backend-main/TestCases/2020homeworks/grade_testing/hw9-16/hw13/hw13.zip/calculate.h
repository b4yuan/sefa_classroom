// ***
// *** DO NOT modify this file
// ***

#ifndef CALCULATE_H
#define CALCULATE_H
#include "list.h"

bool calculate(List * arithlist);

#endif
