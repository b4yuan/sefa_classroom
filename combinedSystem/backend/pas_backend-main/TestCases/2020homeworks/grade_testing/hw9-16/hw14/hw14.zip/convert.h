// ***
// *** DO NOT modify this file
// ***

#ifndef CONVERT_H
#define CONVERT_H
#include "list.h"

bool convert(List * arithlist);

#endif
